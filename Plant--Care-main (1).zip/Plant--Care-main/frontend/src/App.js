import Navbar from './components/Navbar';
import Home from './views/Home';
import MyPlants from './views/MyPlants';
import WateringSchedule from './views/WateringSchedule';
import WateringScheduleInsert from './views/WaterShedulingInsert';
import WateringUpdate from './views/WaterShedulingUpdate';
import './App.css';
import { Route, Routes } from 'react-router-dom';;


function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" default element={<Home />} />
        <Route path="/my-plants" element={<MyPlants />} />
        <Route path="/watering-schedule" element={<WateringSchedule />} />
        <Route path="/watering-schedule-insert" element={<WateringScheduleInsert />} />
        <Route path="/watering-schedule-update/:id" element={<WateringUpdate />} />
      </Routes>
    </>
  );
}

export default App;
