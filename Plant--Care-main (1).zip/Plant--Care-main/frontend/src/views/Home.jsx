import React from "react";
import { useNotificationSettings } from "../contexts/NotificationContext";

function Home() {
  const { settings } = useNotificationSettings();

  return (
    <div>
      <h1>Notification Settings</h1>
      <p>Email Notifications: {settings.email ? "Enabled ✅" : "Disabled ❌"}</p>
      <p>SMS Notifications: {settings.sms ? "Enabled ✅" : "Disabled ❌"}</p>
      <p>Push Notifications: {settings.push ? "Enabled ✅" : "Disabled ❌"}</p>
    </div>
  );
}

export default Home;
