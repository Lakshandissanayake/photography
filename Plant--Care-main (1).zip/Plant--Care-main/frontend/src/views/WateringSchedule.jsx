import React, { useEffect, useState } from "react";
import styles from "../styles/WateringSchedule.module.css";
import { useNavigate } from "react-router-dom";
import { useNotificationSettings } from "../contexts/NotificationContext";
import {
  getWateringSchedule,
  deleteWateringSchedule,

} from "../services/WateringScheduleApi";

function WateringSchedule() {
  const [schedule, setSchedule] = useState([]);

  const navigate = useNavigate();
  const { settings, toggleSetting } = useNotificationSettings();

  // Fetch watering schedule on component mount
  useEffect(() => {
    async function fetchSchedule() {
      try {
        const data = await getWateringSchedule();
        console.log("Fetched Data:", data);
  
        // Ensure it's an array before setting state
        setSchedule(Array.isArray(data?.waterSchedules) ? data.waterSchedules : []);
      } catch (error) {
        console.error("Error fetching watering schedule:", error);
        setSchedule([]); // Set empty array in case of error
      }
    }
    fetchSchedule();
  }, []);
  

  // Handle delete action
 
  const handleDelete = async (id) => {
    try {
      const isDeleted = await deleteWateringSchedule(id);
      
      if (isDeleted) {
        setSchedule((prevSchedule) => prevSchedule.filter((item) => item._id !== id));
      }
      console.log(id);
    } catch (error) {
      console.error("Error deleting schedule:", error);
    }
  };


  return (
    <div className={styles.body}>
      {/* Add New Schedule */}
      <div className={styles.newScheduleContainer}>
        <h1>Water Scheduling</h1>
        <button onClick={() => navigate("/watering-schedule-insert")}>
          + Add New Schedule
        </button>
      </div>

      {/* Watering History */}
      <div className={styles.historyContainer}>
        <h1>Watering History</h1>
        {schedule.length === 0 ? (
          <p className={styles.emptyMessage}>No watering schedule available.</p>
        ) : (
          schedule.map((item) => (
            <div key={item.id}>
              <h2>{item.plantname}</h2>
              <div className={styles.card}>
                <div className={styles.cardSection1}>
                  <p>Frequency: every {item.frequency} Days</p>
                  <p>Time: {item.wateringtime}</p>
                  <p>Weather Adjusted</p>
                </div>
                <div className={styles.cardSection2}>
                  <button className={styles.editButton}
                    onClick={() => navigate(`/watering-schedule-update/${item._id}`)}>
                    Edit</button>
                  <button
                    className={styles.deleteButton}
                    onClick={() => handleDelete(item._id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Notification Setting */}
      <div className={styles.notificationContainer}>
        <h2 className={styles.title}>Notification Setting</h2>
        <div className={styles.options}>
          <label>
            Email Notifications
            <input
              type="checkbox"
              checked={settings.email}
              onChange={() => toggleSetting("email")}
            />
          </label>
          <label>
            SMS Notifications
            <input
              type="checkbox"
              checked={settings.sms}
              onChange={() => toggleSetting("sms")}
            />
          </label>
          <label>
            Push Notifications
            <input
              type="checkbox"
              checked={settings.push}
              onChange={() => toggleSetting("push")}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

export default WateringSchedule;
