const WaterSchedule = require("../models/waterSchedule");

const getAllwaterSchedule = async (req, res, next) => {
  let waterSchedules;
  try {
    waterSchedules = await WaterSchedule.find();
  } catch (err) {
    console.log(err);
  }
  if (!waterSchedules) {
    return res.status(404).json({ message: "No waterSchedules found" });
  }
  return res.status(200).json({ waterSchedules });
};

const addWaterSchedule = async (req, res, next) => {
  const { userid, plantname, frequency, wateringtime, status } = req.body;
  let waterSchedules;
  try {
    waterSchedules = new WaterSchedule({
      userid,
      plantname,
      frequency,
      wateringtime,
      status,
    });
    await waterSchedules.save();
  } catch (err) {
    console.log(err);
  }
  if (!waterSchedules) {
    return res.status(500).json({ message: err });
  }
  return res.status(200).json({ waterSchedules });
};

const getwaterScheduleById = async (req, res, next) => {
  const id = req.params.id;
  let waterSchedules;
  try {
    waterSchedules = await WaterSchedule.findById(id);
  } catch (err) {
    console.log(err);
  }
  if (!waterSchedules) {
    return res.status(404).json({ message: "No waterSchedule found" });
  }
  return res.status(200).json({ waterSchedules });
};

const updatewaterSchedule = async (req, res, next) => {
  const id = req.params.id;
  const { userid, plantname, frequency, wateringtime, status } = req.body;
  let waterSchedules;
  try {
    waterSchedules = await WaterSchedule.findByIdAndUpdate(id, {
      plantname: plantname,
      frequency: frequency,
      wateringtime: wateringtime,
      status: status,
    });
    waterSchedules = await waterSchedules.save();
  } catch (err) {
    console.log(err);
  }
  if (!waterSchedules) {
    return res.status(404).json({ message: "No waterSchedule found" });
  }
  return res.status(200).json({ waterSchedules });
};

const deletewaterSchedule = async (req, res, next) => {
  const id = req.params.id;
  let waterSchedules;
  try {
    waterSchedules = await WaterSchedule.findByIdAndDelete(id);
  } catch (err) {
    console.log(err);
  }
  if (!waterSchedules) {
    return res.status(404).json({ message: "No waterSchedule found" });
  }
  return res.status(200).json({ waterSchedules });
};

exports.getAllwaterSchedule = getAllwaterSchedule;
exports.addWaterSchedule = addWaterSchedule;
exports.getwaterScheduleById = getwaterScheduleById;
exports.updatewaterSchedule = updatewaterSchedule;
exports.deletewaterSchedule = deletewaterSchedule;
