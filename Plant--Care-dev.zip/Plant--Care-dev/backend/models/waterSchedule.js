const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const waterScheduleSchema = new Schema({
    userid: {
        type: String,
        required: true
    },
    plantname: {
        type: String,
        required: true
    },
    frequency: {
        type: String,
        required: true
    },
    wateringtime: {
        type: String,
        required: true
    },
    status: {
        type: Boolean,
        required: true
    }
});

module.exports = mongoose.model(
    "WaterSchedule", waterScheduleSchema);  