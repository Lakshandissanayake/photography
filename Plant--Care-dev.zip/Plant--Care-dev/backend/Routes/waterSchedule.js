const experess = require('express');
const router = experess.Router();
//const WaterSchedule = require("../Model/waterSchedule");
const WaterController = require("../Controllers/waterSchedule");

router.get("/",WaterController.getAllwaterSchedule);
router.post("/",WaterController.addWaterSchedule);
router.get("/:id",WaterController.getwaterScheduleById);
router.put("/:id",WaterController.updatewaterSchedule);
router.delete("/:id",WaterController.deletewaterSchedule);

module.exports = router;