const experess = require('express');
const mongoose = require('mongoose');
const router = require('./Routes/waterSchedule');
const cors =require('cors');
const app = experess();
require('dotenv').config();

//Middleware

app.use(cors());
app.use(experess.json());
app.use("/water",router); 

mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log("Connected to DB"))
.catch((err) => console.log(err));

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));