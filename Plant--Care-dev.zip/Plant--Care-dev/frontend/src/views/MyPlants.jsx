import React from 'react'

function MyPlants() {
  return (
    <div>MyPlants</div>
  )
}

export default MyPlants